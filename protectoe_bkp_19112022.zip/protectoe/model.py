import numpy as np               # NumPy is a Python library used for working with arrays.NumPy stands for Numerical Python. It also has functions for working in domain of linear algebra, fourier transform, and matrices.
import pandas as pd              # It is used for data analysis(restructuring, cleaning or merging, etc) Numpy is required for operating the Pandas. https://www.javatpoint.com/python-pandas
import matplotlib.pyplot as plt     # Matplotlib is a low level graph plotting library in python that serves as a visualization utility. https://www.w3schools.com/python/matplotlib_intro.asp   #Matplotlib is a comprehensive library for creating static, animated, and interactive visualizations in Python.
import seaborn as sns             # Seaborn is a Python data visualization library based on matplotlib. It provides a high-level interface for drawing attractive and informative statistical graphics.. to visualise the distribution
from sklearn.neighbors import KNeighborsClassifier  #Simple and efficient tools for predictive data analysis 
from sklearn.model_selection import train_test_split  #The train_test_split() method is used to split our data into train and test sets.
from sklearn.metrics import accuracy_score   #The accuracy_score method is used to calculate the accuracy of either the faction or count of correct prediction in Python Scikit learn.
import pickle   # used in serializing and deserializing a Python object structure  , “Pickling” is the process whereby a Python object hierarchy is converted into a byte stream, and “unpickling” is the inverse operation, whereby a byte stream (from a binary file or bytes-like object) is converted back into an object hierarchy.
df=pd.read_csv("https://raw.githubusercontent.com/shal4598/Projects/mscit_project/data.csv")
df['SYMPTOM 1'] = df['SYMPTOM 1'].map({'Crumbling Nail':0.0,'Pitting':1.0,'Change in color,Blood under the nails':2.0,'The nail separates from the bed':3.0,'Nail breaks easily':4.0,'Affects both finger nail and toe nail':5.0,'Drying the nails':6.0,'Typically affects only finger nail':7.0,'Thick Nail':8.0,'Discolored nail that are brown,yellow,white':9.0,'Fragile and cracked nail':10.0,'Discoloration of nail yellow,green or opaque':11.0,'Nail pitting,Nail thickening':12.0,"Bending of nail edges":13.0,'Swelling,Tenderness':14.0,"Redness,soreness":15.0,"Pus":16.0,'Genetics,Injury':17.0,'Circulation issues':18.0,'Ichthyosis':19.0,'Swelling':20.0,'Pain,redness':21.0,'Fever and gland pain':22.0,'Yellow pus':23.0})

df['SYMPTOM 2'] = df['SYMPTOM 2'].map({'Crumbling Nail':0.0,'Pitting':1.0,'Change in color,Blood under the nails':2.0,'The nail separates from the bed':3.0,'Nail breaks easily':4.0,'Affects both finger nail and toe nail':5.0,'Drying the nails':6.0,'Typically affects only finger nail':7.0,'Thick Nail':8.0,'Discolored nail that are brown,yellow,white':9.0,'Fragile and cracked nail':10.0,'Discoloration of nail yellow,green or opaque':11.0,'Nail pitting,Nail thickening':12.0,"Bending of nail edges":13.0,'Swelling,Tenderness':14.0,"Redness,soreness":15.0,"Pus":16.0,'Genetics,Injury':17.0,'Circulation issues':18.0,'Ichthyosis':19.0,'Swelling':20.0,'Pain,redness':21.0,'Fever and gland pain':22.0,'Yellow pus':23.0})

df['SYMPTOM 3'] = df['SYMPTOM 3'].map({'Crumbling Nail':0.0,'Pitting':1.0,'Change in color,Blood under the nails':2.0,'The nail separates from the bed':3.0,'Nail breaks easily':4.0,'Affects both finger nail and toe nail':5.0,'Drying the nails':6.0,'Typically affects only finger nail':7.0,'Thick Nail':8.0,'Discolored nail that are brown,yellow,white':9.0,'Fragile and cracked nail':10.0,'Discoloration of nail yellow,green or opaque':11.0,'Nail pitting,Nail thickening':12.0,"Bending of nail edges":13.0,'Swelling,Tenderness':14.0,"Redness,soreness":15.0,"Pus":16.0,'Genetics,Injury':17.0,'Circulation issues':18.0,'Ichthyosis':19.0,'Swelling':20.0,'Pain,redness':21.0,'Fever and gland pain':22.0,'Yellow pus':23.0})

X = df.drop(['DISEASE','TREATMENT'], axis=1)
df['DISEASE'] = df['DISEASE'].map({'Nail psoriasis':0.0,'Brittle Splitting Nails':1.0,'Nail Fungal Infection':2.0,'Onycholysis':3.0,'Ingrown Toenail':4.0,'Onychogryphosis':5.0,'Paronychia':6.0})
Y = df['DISEASE']
X_train, X_test, y_train, y_test = train_test_split(X, Y, test_size=0.33)
model1 = KNeighborsClassifier(n_neighbors=5)
model1.fit(X,Y)
pickle.dump(model1, open('nii_model.pkl','wb'))

model = pickle.load(open('nii_model.pkl','rb'))

