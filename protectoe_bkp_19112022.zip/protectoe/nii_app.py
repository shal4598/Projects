import numpy as np
import pickle
from flask import Flask, request, jsonify, render_template  # Flask is a web application framework written in Python
from flask import Markup

import io
import random
from flask import Response
from matplotlib.backends.backend_agg import FigureCanvasAgg as FigureCanvas
from matplotlib.figure import Figure
from graph import plot_model

app = Flask(__name__)
model = pickle.load(open('nii_model.pkl', 'rb'))


@app.route('/')
@app.route('/<page>')
def showpage(page=None, title=None):
    if page:
        # called with page parameter
        return render_template('%s.html' % page)        
    else:
        # called with no parameters
        return render_template('nii_webapp.html')


@app.route('/predict', methods=['POST'])
def predict():
    res1 = {'Crumbling Nail': 1.0, 'Pitting': 2.0, 'Change in color,Blood under the nails': 3.0,
            'The nail separates from the bed': 4.0, 'Nail breaks easily': 5.0,
            "Affects both finger nail and toe nail": 6.0, 'Drying the nails': 7.0,
            'Typically affects only finger nail': 8.0, 'Thick Nail': 9.0,
            'Discolored nail that are brown,yellow,white': 10.0, 'Fragile and cracked nail': 11.0,
            'Discoloration of nail yellow,green or opaque': 12.0, 'Nail pitting,Nail thickening': 13.0,
            'Bending of nail edges': 14.0, 'Swelling,Tenderness': 15.0, 'Redness,soreness': 16.0, 'Pus': 17.0,
            'Genetics,Injury': 18.0, 'Circulation issues': 19.0, 'Ichthyosis': 20.0, 'Swelling': 21.0,
            'Pain,redness': 22.0, 'Fever and gland pain': 23.0, 'Yellow pus': 24.0}
    int_features = [res1[x] for x in request.form.values()]
    print(int_features)
    final_features = [np.array(int_features)]
    print(final_features)    
    prediction = model.predict(final_features)
    output = abs(int(prediction[0]))
    res = {
        0: '<p>Predicted Disease is Nail psoriasis<br><br>Treatment:Strong Corticosteroids,injection of Corticosteroids and laser treatment. Click <a href="https://www.practo.com/mumbai/doctors-for-nail-diseases-treatment" style="color:red;">here</a> to book an appointment.</p>',
        1: '<p>Predicted Disease is Brittle Splitting Nails<br><br>Treatment:Apply moisturizer to the infected nail</p>',
        2: '<p>Predicted Disease is Nail Fungal Infection<br><br>Treatment:Antifungal Medication</p>',
        3: '<p>Predicted Disease is Onycholysis<br><br>Treatment:Treating psoriasis with oral antifungal medication</p>',
        4: '<p>Predicted Disease is Ingrown Toenail<br><br>Treatment:Surgery, Must visit Podiatrist or Dermatologist. Click <a href="https://www.practo.com/mumbai/doctors-for-nail-diseases-treatment" style="color:red;">here</a> to book an appointment. </p>',
        5: '<p>Predicted Disease is Onychogryphosis<br><br>Treatment:Podiatrist or Dermatologist. Click <a href="https://www.practo.com/mumbai/doctors-for-nail-diseases-treatment" style="color:red;">here</a> to book an appointment.</p>',
        6: '<p>Predicted Disease is Paronychia<br><br>Treatment:Tropical or oral antibiotics,corticosteroids</p>'}
    output = res[output]
    output = Markup(output)
    return render_template('nii_webapp.html', prediction_text=output, url="static\plot.png")


@app.route('/results', methods=['POST'])
def results():
    data = request.get_json(force=True)
    prediction = model.predict([np.array(list(data.values()))])
    
    output = prediction[0]
    return jsonify(output)
########## adding graph
plot_model()
@app.route('/plot.png')
def plot_png():
    fig = create_figure()
    output = io.BytesIO()
    FigureCanvas(fig).print_png(output)
    return Response(output.getvalue(), mimetype='image/png')

def create_figure():
    fig = Figure()
    axis = fig.add_subplot(1, 1, 1)
    xs = range(100)
    ys = [random.randint(1, 50) for x in xs]
    axis.plot(xs, ys)
    return fig
##############

if __name__ == "__main__":
    app.run(debug=True)
