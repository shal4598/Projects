/*slide show functions*/
  $(function() {
    setTimeout(function() { $("#mySlides1").fadeOut(2350); }, 100)
  })
  var indexValue = 0;
  function slideShow(){
    setTimeout(slideShow, 2500);
    var x;
    const img = document.getElementsByClassName("mySlides");
    for(x = 0; x < img.length; x++){
      img[x].style.display = "none";

    }
    indexValue++;
    if(indexValue > img.length){indexValue = 1}
    img[indexValue -1].style.display = "block";

  }
  slideShow();
  /*fade left animation*/
  function reveal() {
  var reveals = document.querySelectorAll(".reveal");
  for (var i = 0; i < reveals.length; i++) {
    var windowHeight = window.innerHeight;
    var elementTop = reveals[i].getBoundingClientRect().top;
    var elementVisible = 150;
    if (elementTop < windowHeight - elementVisible) {
      reveals[i].classList.add("active");
    } else {
      reveals[i].classList.remove("active");
    }
  }}
  window.addEventListener("scroll", reveal);
  /*fade right animation*/
  function reveal1() {
  var reveals1 = document.querySelectorAll(".reveal1");
  for (var i = 0; i < reveals1.length; i++) {
    var windowHeight = window.innerHeight;
    var elementTop = reveals1[i].getBoundingClientRect().top;
    var elementVisible = 150;
    if (elementTop < windowHeight - elementVisible) {
      reveals1[i].classList.add("active1");
    } else {
      reveals1[i].classList.remove("active1");
    }
  }}
  window.addEventListener("scroll", reveal1);
  /*fade top animation*/
  function reveal2() {
  var reveals2 = document.querySelectorAll(".reveal2");
  for (var i = 0; i < reveals2.length; i++) {
    var windowHeight = window.innerHeight;
    var elementTop = reveals2[i].getBoundingClientRect().top;
    var elementVisible = 150;
    if (elementTop < windowHeight - elementVisible) {
      reveals2[i].classList.add("active2");
    } else {
      reveals2[i].classList.remove("active2");
    }
  }}
  window.addEventListener("scroll", reveal2);

   /* onloader function*/
   $(window).on('load', function () {
           $(".container").fadeOut("slow");
      });

  /*risk level prediction function*/
  function add()
  {
    var numOne, numTwo, numThree,sum;
    numOne = parseInt(document.getElementById("first").value);
    numTwo = parseInt(document.getElementById("second").value);
    numThree= parseInt(document.getElementById("third").value);
    sum = ((numOne + numTwo +numThree)/3)*10;
    l=sum;
    if( isNaN(numOne) || isNaN(numTwo) || isNaN(numThree)){
        document.getElementById("text").innerHTML ="Please enter the number values range from 1-10";}
    else if(numOne>10||numOne<1||numTwo>10||numTwo<1||numThree>10||numThree<1){
        document.getElementById("text").innerHTML ="Please enter the number values range from 1-10";}
    else if(l>=0 && l<=20){
               document.getElementById("answer").value = sum.toFixed();
          document.getElementById("text").innerHTML ="Consult a Doctor for Medication. Checkup is recommended.";}
    else if(l>=21 && l<=40){
                document.getElementById("answer").value = sum.toFixed();
          document.getElementById("text").innerHTML ="medication is compulsory.Must  Go for checkup at periodical time.";}
    else if(l>=41 && l<=60){
                document.getElementById("answer").value = sum.toFixed();
          document.getElementById("text").innerHTML="Consultation and Medication must be taken. consult doctor weekly twice and follow the mediation.";}
    else if(l>=61 && l<=80){
                document.getElementById("answer").value = sum.toFixed();
          document.getElementById("text").innerHTML ="Medication or surgery (if should) must be taken. test and consultation is compulsory.";}
    else{
                document.getElementById("answer").value = sum.toFixed();
          document.getElementById("text").innerHTML ="Immediate Consultation and sugery(If must) must be done. follow medication before or after surgery if done.";}
  }
